let person = {
  x: 100,
  y: 270,
  w: 30,
  h: 60
};

let trashBags = [];
let totalTrash = 15;
let collectedCount = 0;
let gameOver = false;
let particles = [];
let cars = [];
let currentTrash = null;

function setup() {
  createCanvas(600, 400);
  textFont('Arial');
  
  // Cria primeiro lixo
  spawnNewTrash();
  
  // Cria carros
  for (let i = 0; i < 3; i++) {
    cars.push({
      x: random(-200, -100),
      y: 340,
      w: 60,
      h: 30,
      color: color(random(100, 255), random(100, 255), random(100, 255)),
      speed: random(1, 3)
    });
  }
}

function draw() {
  background(135, 206, 235);

  if (gameOver) {
    drawVictoryScreen();
    return;
  }

  movePlayer();
  constrainPlayerPosition();
  drawSunAndClouds();
  drawBuildings();
  drawStreet();
  drawCars();
  drawStatusBar();

  // Desenha o lixo atual
  if (currentTrash) {
    drawTrashBag(currentTrash.x, currentTrash.y, currentTrash.size);
    
    // Verifica colisão
    if (dist(person.x + person.w/2, person.y + person.h/2, currentTrash.x, currentTrash.y) < 30) {
      collectedCount++;
      createParticles(currentTrash.x, currentTrash.y);
      
      if (collectedCount >= totalTrash) {
        gameOver = true;
      } else {
        spawnNewTrash();
      }
    }
  }

  drawParticles();
  drawPerson(person.x, person.y, person.w, person.h);
}

function spawnNewTrash() {
  currentTrash = {
    x: random(50, width - 50),
    y: random(270, 350),
    size: random(0.5, 0.8),
    collected: false
  };
}

function drawVictoryScreen() {
  background(0);
  
  // Mensagem de vitória
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("Obrigado por jogar", width/2, height/2 - 20);
  
  textSize(20);
  text("Clique espaço para jogar novamente", width/2, height/2 + 20);
}

function movePlayer() {
  let speed = 3;
  if (keyIsDown(LEFT_ARROW)) person.x -= speed;
  if (keyIsDown(RIGHT_ARROW)) person.x += speed;
  if (keyIsDown(UP_ARROW)) person.y -= speed;
  if (keyIsDown(DOWN_ARROW)) person.y += speed;
}

function constrainPlayerPosition() {
  person.x = constrain(person.x, 0, width - person.w);
  person.y = constrain(person.y, 0, height - person.h);
}

function drawSunAndClouds() {
  fill(255, 255, 0);
  ellipse(550, 70, 60, 60);
  
  fill(255);
  ellipse(100, 80, 60, 40);
  ellipse(130, 80, 50, 30);
  ellipse(120, 60, 50, 30);
  ellipse(300, 100, 70, 40);
  ellipse(330, 90, 50, 30);
  ellipse(310, 80, 60, 30);
}

function drawBuildings() {
  let colors = [color(60), color(80), color(100), color(40, 40, 80)];
  for (let i = 0; i < 10; i++) {
    let x = i * 60, w = 50, h = 180 + (i % 3) * 40;
    fill(colors[i % colors.length]);
    rect(x, 400 - h, w, h);
    
    fill(255, 255, 100);
    for (let j = 400 - h + 10; j < 380; j += 30) {
      rect(x + 10, j, 10, 15);
      rect(x + 30, j, 10, 15);
    }
  }
}

function drawStreet() {
  fill(50);
  rect(0, 370, width, 30);
  
  stroke(255);
  strokeWeight(4);
  for (let i = 0; i < width; i += 40) {
    line(i, 385, i + 20, 385);
  }
  noStroke();
}

function drawCars() {
  for (let i = 0; i < cars.length; i++) {
    let car = cars[i];
    
    fill(car.color);
    rect(car.x, car.y, car.w, car.h);
    
    fill(200, 200, 255, 150);
    rect(car.x + 10, car.y + 5, 20, 10);
    rect(car.x + 35, car.y + 5, 15, 10);
    
    fill(0);
    ellipse(car.x + 15, car.y + car.h, 12, 12);
    ellipse(car.x + car.w - 15, car.y + car.h, 12, 12);
    
    car.x += car.speed;
    if (car.x > width + 50) {
      car.x = random(-200, -100);
      car.speed = random(1, 3);
    }
  }
}

function drawStatusBar() {
  fill(0, 0, 0, 100);
  rect(0, 0, width, 30);
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  text("🗑️ Lixos coletados: " + collectedCount + "/" + totalTrash, 10, 15);
}

function createParticles(x, y) {
  for (let i = 0; i < 10; i++) {
    particles.push({
      x: x, y: y,
      size: random(3, 8),
      speedX: random(-2, 2),
      speedY: random(-2, 2),
      life: 30
    });
  }
}

function drawParticles() {
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    fill(255, 215, 0, p.life * 8);
    ellipse(p.x, p.y, p.size);
    p.x += p.speedX;
    p.y += p.speedY;
    p.life--;
    if (p.life <= 0) particles.splice(i, 1);
  }
}

function keyPressed() {
  if (gameOver && key === ' ') {
    // Reinicia o jogo
    collectedCount = 0;
    gameOver = false;
    spawnNewTrash();
  }
}

function drawPerson(px, py, pw, ph) {
  push();
  scale(pw / 60, ph / 120);
  translate(px / (pw / 60), py / (ph / 120));

  // Corpo
  fill(0, 150, 200);
  rect(0, 0, 60, 80);

  // Pernas
  fill(50);
  rect(0, 80, 20, 40);
  rect(40, 80, 20, 40);

  // Braços
  fill(255, 220, 180);
  rect(-30, 10, 30, 15);
  rect(60, 10, 30, 15);

  // Cabeça
  fill(255, 220, 180);
  ellipse(30, -30, 50, 50);

  // Cabelo
  fill(60, 40, 20);
  arc(30, -40, 50, 50, PI, 0);

  // Olhos e boca
  fill(0);
  ellipse(20, -35, 5, 5);
  ellipse(40, -35, 5, 5);
  stroke(0);
  line(20, -20, 40, -20);
  
  pop();
}

function drawTrashBag(x, y, scaleFactor) {
  push();
  translate(x, y);
  scale(scaleFactor);

  fill(30);
  stroke(10);
  strokeWeight(2);
  beginShape();
  curveVertex(-20, 0);
  curveVertex(-20, 0);
  curveVertex(-25, -20);
  curveVertex(0, -35);
  curveVertex(25, -20);
  curveVertex(20, 0);
  curveVertex(20, 0);
  endShape(CLOSE);

  fill(20);
  ellipse(0, -35, 10, 10);

  noStroke();
  fill(80);
  ellipse(-10, -10, 10, 20);
  ellipse(10, -15, 8, 15);
  pop();
}
